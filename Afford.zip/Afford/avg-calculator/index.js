const express = require('express');
const app = express();
const PORT = 9000;
app.use(express.json());
app.post('/calculate-average', (req, res) => {
    const { numbers } = req.body;
    if (!Array.isArray(numbers) || numbers.length === 0) {
        return res.status(400).json({ error: 'Please provide a valid array of numbers.' });
    }
    if (!numbers.every(num => typeof num === 'number')) {
        return res.status(400).json({ error: 'All elements in the array must be numbers.' });
    }
    const sum = numbers.reduce((acc, num) => acc + num, 0);
    const average = sum / numbers.length;
    res.status(200).json({
        numbers,
        average,
        total: sum,
        count: numbers.length
    });
});
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found. Use POST /calculate-average' });
});
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
